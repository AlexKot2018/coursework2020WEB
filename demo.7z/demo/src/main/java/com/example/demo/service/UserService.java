package com.example.demo.service;

import com.example.demo.model.Users;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


import java.util.List;
@Service
public class UserService {

    private UserRepository userRepository;

    @Autowired
    public UserService(UserRepository userRepository){
        this.userRepository = userRepository;
    }
    public Users findById(Long id){
        return userRepository.getOne(id);
    }
    public List<Users> findAll(){
        return userRepository.findAll();
    }
    public Users saveUser(Users user){
       return userRepository.save(user);
    }
    public void deleteById(Long id){
        userRepository.deleteById(id);

    }
}
